:HL["/_next/static/chunks/3ebjjm-unbddc.css","style"]
:HL["/_next/static/media/03bda585a99c6450-s.p.32sris142tqlb.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"trips","param":null,"prefetchHints":0,"slots":{"children":{"name":"slug","param":{"type":"d","key":"bali-divine-feminine","siblings":null},"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"GCU5GAX3NPfgIc3rmRt0e"}
