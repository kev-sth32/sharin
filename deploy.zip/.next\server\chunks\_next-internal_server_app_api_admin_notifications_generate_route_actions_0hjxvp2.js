module.exports=[50868,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_notifications_generate_route_actions_0hjxvp2.js.map