"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Calendar, Briefcase, Users } from "lucide-react";
import { openEnquiryModal } from "@/lib/utils";

const WhatsAppIcon = (props: any) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.625 1.451 5.437.002 9.861-4.416 9.864-9.852.002-2.63-1.023-5.101-2.885-6.963C16.388 1.928 13.916.904 11.285.902c-5.439 0-9.863 4.417-9.867 9.853-.001 1.73.457 3.419 1.328 4.908l-.989 3.613 3.708-.973zm11.58-6.143c-.302-.15-1.788-.882-2.057-.98-.268-.099-.463-.149-.658.15-.195.299-.754.98-.925 1.178-.17.199-.341.224-.643.075-.302-.15-1.273-.469-2.427-1.498-.897-.8-1.502-1.787-1.678-2.087-.177-.3-.019-.462.13-.611.135-.134.302-.35.454-.523.151-.174.2-.299.302-.498.101-.2.05-.374-.025-.523-.075-.15-.658-1.588-.901-2.173-.236-.57-.497-.493-.68-.5-.187-.008-.401-.01-.614-.01s-.56.08-.853.4c-.293.32-1.12 1.1-1.12 2.68 0 1.58 1.147 3.11 1.307 3.32.16.21 2.257 3.45 5.47 4.83.763.329 1.36.526 1.822.673.768.243 1.467.209 2.02.127.616-.093 1.788-.732 2.042-1.44.254-.707.254-1.314.178-1.44-.076-.124-.268-.199-.57-.348z" />
  </svg>
);

const InstagramIcon = (props: any) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </svg>
);

interface HeroProps {
  settings?: {
    heroBadge?: string;
    heroTitle?: string;
    heroSubtitle?: string;
    urgencyText?: string;
    heroImages?: string[];
    heroTitleSize?: string;
    heroSubtitleSize?: string;
    pill1Badge?: string;
    pill1Title?: string;
    pill1Desc?: string;
    pill2Badge?: string;
    pill2Title?: string;
    pill2Desc?: string;
  };
}

const isVideo = (url: string) => /\.(mp4|webm|ogg)($|\?)/i.test(url);

const defaultHeroBadge = "Women-Only Travel Experience";
const defaultHeroTitle = "Solo on Paper.<br />\n<span class=\"font-serif italic font-normal text-[#FF4A7D]\">Together in Spirit.</span>";
const defaultHeroSubtitle = "Discover safety-first small group trips for women. Experience local cultures, form lifetime friendships, and explore the world with our experienced Trip Leaders.";
const defaultUrgencyText = "⚡ {count} Naaris enquired last hour";
const defaultHeroImages = [
  "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=1600&q=80",
  "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1600&q=80",
  "https://images.unsplash.com/photo-1527631746610-bca00a040d60?w=1600&q=80"
];

const titleSizeMap: Record<string, string> = {
  "Small": "text-[18px] sm:text-[22px] md:text-[26px] xl:text-[30px] 2xl:text-[36px]",
  "Medium": "text-[20px] sm:text-[25px] md:text-[30px] xl:text-[34px] 2xl:text-[40px]",
  "Large": "text-[22px] sm:text-[28px] md:text-[32px] xl:text-[36px] 2xl:text-[42px]",
  "Extra Large": "text-[26px] sm:text-[32px] md:text-[38px] xl:text-[42px] 2xl:text-[50px]"
};

const subtitleSizeMap: Record<string, string> = {
  "Small": "text-[11px] xl:text-[12px]",
  "Medium": "text-[12px] xl:text-[13px]",
  "Large": "text-[13px] xl:text-[15px]"
};

export default function Hero({ settings }: HeroProps) {
  // Initialize to a random start count (e.g. between 34 and 48)
  const [enquiryCount, setEnquiryCount] = useState(() => Math.floor(Math.random() * 15) + 34);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const heroImages = settings?.heroImages || defaultHeroImages;
  const badgeText = settings?.heroBadge || defaultHeroBadge;
  const titleHtml = settings?.heroTitle || defaultHeroTitle;
  const subtitleText = settings?.heroSubtitle || defaultHeroSubtitle;
  const urgencyTemplate = settings?.urgencyText || defaultUrgencyText;

  const titleSizeClass = titleSizeMap[settings?.heroTitleSize || "Large"] || titleSizeMap["Large"];
  const subtitleSizeClass = subtitleSizeMap[settings?.heroSubtitleSize || "Medium"] || subtitleSizeMap["Medium"];

  const pill1Badge = settings?.pill1Badge || "Most Loved";
  const pill1Title = settings?.pill1Title || "Kashmir Tulip • 5D";
  const pill1Desc = settings?.pill1Desc || "₹21,999 • 8 seats";

  const pill2Badge = settings?.pill2Badge || "Weekend";
  const pill2Title = settings?.pill2Title || "Tirthan 3D • Solo";
  const pill2Desc = settings?.pill2Desc || "₹9,999 • Fri";

  useEffect(() => {
    const interval = setInterval(() => {
      setEnquiryCount((prev) => {
        // Slow natural live fluctuation: randomly adjust by -2, -1, 0, 1, or 2
        const change = Math.floor(Math.random() * 5) - 2;
        const nextVal = prev + change;
        // Keep inside a realistic range (25 - 55)
        if (nextVal < 25) return 25 + Math.floor(Math.random() * 5);
        if (nextVal > 55) return 55 - Math.floor(Math.random() * 5);
        return nextVal;
      });
    }, 25000); // Updates slowly every 25 seconds
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (heroImages.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroImages]);

  const formattedUrgency = urgencyTemplate.replace("{count}", enquiryCount.toString());

  return (
    <section className="relative bg-[#FFF8F0]">
      {/* Dark maroon/burgundy hero background container */}
      <div className="relative overflow-hidden bg-[#6a0c24] text-white">
        <div className="absolute inset-0">
          {heroImages.map((imgUrl, idx) => (
            isVideo(imgUrl) ? (
              <video
                key={imgUrl}
                src={imgUrl}
                autoPlay
                loop
                muted
                playsInline
                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                  idx === currentImageIndex ? "opacity-100" : "opacity-0"
                }`}
              />
            ) : (
              <img
                key={imgUrl}
                src={imgUrl}
                alt={`Women traveling slide ${idx + 1}`}
                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                  idx === currentImageIndex ? "opacity-100" : "opacity-0"
                }`}
              />
            )
          ))}
          <div className="absolute inset-0 bg-black/50" />
        </div>
        <div className="relative max-w-[1280px] mx-auto px-4 md:px-8 pt-12 pb-24 lg:pt-16 lg:pb-28 xl:pt-24 xl:pb-36 2xl:pt-32 2xl:pb-48">
          <div className="grid lg:grid-cols-12 gap-6 items-center lg:pt-2">
            <div className="lg:col-span-5 text-center lg:text-left space-y-4 lg:pr-2">
              <div className="inline-flex items-center rounded-full bg-white/10 backdrop-blur-sm border border-white/20 px-3 py-1 text-[8.5px] font-bold tracking-[0.15em] uppercase text-white/90 shadow-sm">
                {badgeText}
              </div>
              <h1 
                className={`font-display font-[800] tracking-tight leading-[1.12] text-white text-balance max-w-4xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)] ${titleSizeClass}`}
                dangerouslySetInnerHTML={{ __html: titleHtml }}
              />
              <p className={`leading-relaxed text-white/80 max-w-[46ch] text-balance font-medium drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)] ${subtitleSizeClass}`}>
                {subtitleText}
              </p>
              <div className="mt-4 lg:mt-6 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start items-center">
                <a
                  href="https://chat.whatsapp.com/IdH8AumJHbQ3A8th9VkQts?s=cl&p=a&mlu=1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto"
                >
                  <Button className="w-full sm:w-auto bg-gradient-to-r from-[#FF4A7D] to-[#FF758F] hover:from-[#E63E6E] hover:to-[#FF4A7D] text-white rounded-full font-bold px-6 text-xs h-10 shadow-[0_4px_15px_-4px_rgba(255,74,125,0.4)] hover:shadow-[0_8px_25px_-5px_rgba(255,74,125,0.55)] inline-flex items-center justify-center gap-1.5 border-none transition-all hover:scale-[1.03]">
                    <WhatsAppIcon className="w-4 h-4" />
                    Join Community
                  </Button>
                </a>
                <a
                  href="https://instagram.com/tripnaari"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto"
                >
                  <Button variant="outline" className="w-full sm:w-auto bg-white/5 backdrop-blur-sm border border-white/20 hover:border-white/50 text-white hover:bg-white/10 rounded-full font-bold px-6 text-xs h-10 inline-flex items-center justify-center gap-1.5 transition-all hover:scale-[1.03]">
                    <InstagramIcon className="w-4 h-4" />
                    Follow on Instagram
                  </Button>
                </a>
              </div>
            </div>
            <div className="hidden lg:block lg:col-span-3" />
            <div className="lg:col-span-4 flex justify-center lg:justify-end">
              <div className="w-full max-w-[320px] bg-gradient-to-br from-white via-white/95 to-[#FFF8F0]/90 rounded-[24px] p-4 md:p-5 border border-white/20 shadow-[0_24px_50px_-12px_rgba(0,0,0,0.22),0_12px_24px_-10px_rgba(255,74,125,0.08)] text-[#13253D] backdrop-blur-md">
                <div className="text-[9px] font-extrabold uppercase tracking-wider text-[#FF4A7D]/85 leading-tight text-center">
                  Quick Enquiry • 2 Min • 2 Hours Response
                </div>
                <h3 className="font-display font-[800] text-[15px] md:text-[16px] 2xl:text-[18px] text-[#13253D] leading-[1.15] mt-2 mb-3.5 text-center">
                  Where do you want to go next, Naari?
                </h3>
                <div className="grid grid-cols-2 gap-2.5 mb-3.5">
                  <button
                    onClick={() => openEnquiryModal()}
                    className="flex flex-col text-left p-2 rounded-xl bg-[#FFF8F0]/60 border border-[#FF4A7D]/5 hover:border-[#FF4A7D]/25 hover:bg-[#FFF0F4]/80 transition-all duration-300 group/pill shadow-[0_2px_8px_rgba(255,74,125,0.02)]"
                  >
                    <span className="text-[7px] font-extrabold text-[#FF4A7D] uppercase tracking-wider">{pill1Badge}</span>
                    <span className="text-[11px] font-extrabold text-[#13253D] mt-0.5 group-hover/pill:text-[#FF4A7D] transition-colors">{pill1Title}</span>
                    <span className="text-[9px] text-[#3D4A5E]/80 mt-0.5 font-semibold">{pill1Desc}</span>
                  </button>
                  <button
                    onClick={() => openEnquiryModal()}
                    className="flex flex-col text-left p-2 rounded-xl bg-[#FFF8F0]/60 border border-[#FF4A7D]/5 hover:border-[#FF4A7D]/25 hover:bg-[#FFF0F4]/80 transition-all duration-300 group/pill shadow-[0_2px_8px_rgba(255,74,125,0.02)]"
                  >
                    <span className="text-[7px] font-extrabold text-[#FF4A7D] uppercase tracking-wider">{pill2Badge}</span>
                    <span className="text-[11px] font-extrabold text-[#13253D] mt-0.5 group-hover/pill:text-[#FF4A7D] transition-colors">{pill2Title}</span>
                    <span className="text-[9px] text-[#3D4A5E]/80 mt-0.5 font-semibold">{pill2Desc}</span>
                  </button>
                </div>
                <div className="flex items-center justify-center gap-1.5 bg-[#FFF0F4]/80 text-[#FF4A7D] border border-[#FF4A7D]/15 rounded-full py-1 px-3.5 mb-3.5 text-[10px] font-bold tracking-wide uppercase shadow-sm w-fit mx-auto animate-fade-in">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#25D366] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#25D366]"></span>
                  </span>
                  <span>{formattedUrgency}</span>
                </div>
                <button
                  onClick={() => openEnquiryModal()}
                  className="w-full text-center rounded-full bg-gradient-to-r from-[#FF4A7D] to-[#FF758F] hover:from-[#E63E6E] hover:to-[#FF4A7D] text-white font-extrabold text-xs py-2.5 transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_8px_25px_-5px_rgba(255,74,125,0.45)] shadow-[0_4px_12px_-4px_rgba(255,74,125,0.3)]"
                >
                  Check availability →
                </button>
                <p className="text-[9px] text-[#3D4A5E]/70 text-center mt-2.5 font-medium leading-relaxed">
                  No spam, itinerary on WhatsApp. Cancellation policy transparent.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="relative -mt-8 md:-mt-12 lg:-mt-6 xl:-mt-16 z-20 max-w-[1100px] mx-auto px-4 md:px-8">
        <div className="bg-white rounded-3xl shadow-[0_20px_50px_-12px_rgba(19,37,61,0.12)] border border-[#F1D9D0] p-6 md:p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 md:gap-4 md:divide-x md:divide-[#F1D9D0]/80">
            {/* Stat 1 */}
            <div className="flex flex-col items-center text-center p-4 pb-6 border-r border-b border-[#F1D9D0]/80 md:border-0 md:p-4">
              <div className="w-12 h-12 rounded-full bg-[#FFF0F4] border border-[#FF4A7D]/20 flex items-center justify-center text-[#FF4A7D] mb-3">
                <Users className="w-5 h-5" />
              </div>
              <div className="font-display font-[800] text-[24px] md:text-[28px] text-[#13253D] leading-none">
                6,000+
              </div>
              <div className="text-[12px] md:text-[13px] font-bold text-[#FF4A7D] tracking-wider uppercase mt-2">
                Travellers
              </div>
            </div>

            {/* Stat 2 */}
            <div className="flex flex-col items-center text-center p-4 pb-6 border-b border-[#F1D9D0]/80 md:border-0 md:p-4">
              <div className="w-12 h-12 rounded-full bg-[#FFF0F4] border border-[#FF4A7D]/20 flex items-center justify-center text-[#FF4A7D] mb-3">
                <Briefcase className="w-5 h-5" />
              </div>
              <div className="font-display font-[800] text-[24px] md:text-[28px] text-[#13253D] leading-none">
                75+
              </div>
              <div className="text-[12px] md:text-[13px] font-bold text-[#FF4A7D] tracking-wider uppercase mt-2">
                Destinations
              </div>
            </div>

            {/* Stat 3 */}
            <div className="flex flex-col items-center text-center p-4 pt-6 border-r border-[#F1D9D0]/80 md:border-0 md:p-4">
              <div className="w-12 h-12 rounded-full bg-[#FFF0F4] border border-[#FF4A7D]/20 flex items-center justify-center text-[#FF4A7D] mb-3">
                <Calendar className="w-5 h-5" />
              </div>
              <div className="font-display font-[800] text-[24px] md:text-[28px] text-[#13253D] leading-none">
                500+
              </div>
              <div className="text-[12px] md:text-[13px] font-bold text-[#FF4A7D] tracking-wider uppercase mt-2">
                Trips
              </div>
            </div>

            {/* Stat 4 */}
            <div className="flex flex-col items-center text-center p-4 pt-6 md:border-0 md:p-4">
              <div className="w-12 h-12 rounded-full bg-[#FFF0F4] border border-[#FF4A7D]/20 flex items-center justify-center text-[#FF4A7D] mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="font-display font-[800] text-[24px] md:text-[28px] text-[#13253D] leading-none">
                100%
              </div>
              <div className="text-[12px] md:text-[13px] font-bold text-[#FF4A7D] tracking-wider uppercase mt-2">
                Safety Rate
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

