var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/subscribe/route.js")
R.c("server/chunks/[root-of-the-server]__16x2r4a._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/[root-of-the-server]__156sndz._.js")
R.c("server/chunks/_next-internal_server_app_api_push_subscribe_route_actions_209jg7g.js")
R.m(66779)
module.exports=R.m(66779).exports
