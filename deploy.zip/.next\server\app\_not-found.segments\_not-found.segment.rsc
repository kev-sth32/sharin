1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0d--xggs96671.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2l3o-5ecmo0dl.js"],"default"]
3:I[37457,["/_next/static/chunks/0d--xggs96671.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2l3o-5ecmo0dl.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"_Ct4_PonEya3o_cmY5CJ1"}
