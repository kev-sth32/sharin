globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/GCU5GAX3NPfgIc3rmRt0e/_buildManifest.js",
    "static/GCU5GAX3NPfgIc3rmRt0e/_ssgManifest.js",
    "static/GCU5GAX3NPfgIc3rmRt0e/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/0ha4m18glnjqn.js",
    "static/chunks/1--cgnh_vjpor.js",
    "static/chunks/25o46h8mdjlrg.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/32zfk5zgzsdp4.js",
    "static/chunks/turbopack-05275dpf30ali.js"
  ]
};
