var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/subscribe/route.js")
R.c("server/chunks/[root-of-the-server]__0wz-0w2._.js")
R.c("server/chunks/[root-of-the-server]__16xri54._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_push_subscribe_route_actions_209jg7g.js")
R.m(66779)
module.exports=R.m(66779).exports
