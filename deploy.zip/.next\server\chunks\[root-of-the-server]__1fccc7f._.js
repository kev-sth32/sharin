module.exports=[79594,(e,t,a)=>{t.exports=e.x("dns",()=>require("dns"))},61378,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),n=e.i(59756),o=e.i(61916),i=e.i(74677),s=e.i(69741),l=e.i(16795),d=e.i(87718),c=e.i(95169),u=e.i(47587),p=e.i(66012),h=e.i(70101),m=e.i(26937),g=e.i(10372),f=e.i(93695);e.i(52474);var A=e.i(220),T=e.i(89171),E=e.i(40749),y=e.i(84935),I=e.i(3236);function N(e){let t=new TextEncoder;return new Response(new ReadableStream({start(a){a.enqueue(t.encode(e)),a.close()}}),{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}function x(e){if(!e||!Array.isArray(e))return null;let t=["kashmir","kerala","meghalaya","rajasthan","spiti","goa","gokarna","tirthan","jibhi","bali"];for(let a=e.length-1;a>=0;a--){let r=(e[a].content||"").toLowerCase();for(let e of t)if(r.includes(e))return e}return null}async function w(e){try{let t,{messages:a,role:r,context:n,tempSettings:o,conversationId:i}=await e.json();if(!a||!Array.isArray(a))return T.NextResponse.json({error:"Invalid messages array"},{status:400});if("admin"===r&&!(e.headers.get("cookie")||"").includes("tripnaari_admin=authenticated"))return T.NextResponse.json({error:"Unauthorized — Admin session required"},{status:401});let s=(0,E.getAISettings)(),l="admin"===r&&o?{...s,...o}:s,d=l.nvidiaApiKey||process.env.NVIDIA_API_KEY,c=i||`conv_${Date.now()}`,u="customer"===r,p=process.env.GEMINI_API_KEY,h=p&&"your_key_here"!==p&&"re_xxxxxxxxxxxxxxxx"!==p;if(!(d&&"your_key_here"!==d&&"re_xxxxxxxxxxxxxxxx"!==d)){if(h)return R(a,r,n,p,l,c);return N("⚠️ **NaariAI Assistant:** API keys are not configured. Please set a valid Nvidia NIM API Key in the AI Settings dashboard, or add your `GEMINI_API_KEY` to the environment variables.")}let m=x(a),g="";if("admin"===r&&n?.source!=="sandbox_testing"){let e=await (0,I.getAdminDataShared)();g=C(n,e)}else g=v(l,m);let f=[{role:"system",content:g},...a.map(e=>{let t="user";return("assistant"===e.role||"model"===e.role||"system"===e.role)&&(t="assistant"),{role:t,content:e.content||""}})],A=new AbortController,w=setTimeout(()=>A.abort(),6e3);try{t=await fetch("https://integrate.api.nvidia.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${d}`},body:JSON.stringify({model:l.modelName||"meta/llama-3.1-70b-instruct",messages:f,temperature:void 0!==l.temperature?Number(l.temperature):"admin"===r?.5:.2,max_tokens:1e3,stream:!0}),signal:A.signal}),clearTimeout(w)}catch(t){clearTimeout(w),console.error("Nvidia API connection failed or timed out:",t);let e=process.env.GEMINI_API_KEY;if(e&&"your_key_here"!==e&&"re_xxxxxxxxxxxxxxxx"!==e){console.warn("Attempting Gemini fallback...");try{return await R(a,r,n,e,l,c)}catch(e){console.error("Gemini Fallback failed:",e)}}return console.warn("Nvidia connection failed/timed-out and no Gemini fallback available."),N("⚠️ **NaariAI Assistant Connection Error:** Failed to connect to Nvidia NIM API (connection timed out or reset).")}if(!t.ok){let e=await t.json().catch(()=>({}));console.error("Nvidia API Error:",e);let o=process.env.GEMINI_API_KEY;if(o&&"your_key_here"!==o&&"re_xxxxxxxxxxxxxxxx"!==o){console.warn("Attempting Gemini fallback...");try{return await R(a,r,n,o,l,c)}catch(e){console.error("Gemini Fallback failed:",e)}}let i=e.detail||e.message||"Unknown error";return N(`⚠️ **NaariAI Assistant API Error:** Nvidia API returned an error: "${i}".`)}let S=new TextEncoder,b=new TextDecoder,O=new ReadableStream({async start(e){if(!t.body)return void e.close();let o=t.body.getReader(),i="",s="";try{for(;;){let{done:t,value:a}=await o.read();if(t)break;let r=(i+=b.decode(a,{stream:!0})).split("\n");for(let t of(i=r.pop()||"",r)){let a=t.trim();if(a&&"data: [DONE]"!==a&&a.startsWith("data: "))try{let t=a.slice(6),r=JSON.parse(t),n=r.choices?.[0]?.delta?.content||"";n&&(e.enqueue(S.encode(n)),s+=n)}catch(e){}}}if(i&&i.startsWith("data: "))try{let t=i.slice(6).trim();if("[DONE]"!==t){let a=JSON.parse(t),r=a.choices?.[0]?.delta?.content||"";r&&(e.enqueue(S.encode(r)),s+=r)}}catch(e){}u&&await (0,y.logConversation)(c,a,s,r,n)}catch(t){console.error("Error reading stream:",t),e.error(t)}finally{e.close()}}});return new Response(O,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("API Route Chat Error:",e),T.NextResponse.json({error:"Internal Server Error",message:e.message},{status:500})}}async function R(e,t,a,r,n,o){let i,s=x(e),l="";l="admin"===t&&a?.source!=="sandbox_testing"?C(a,await (0,I.getAdminDataShared)()):v(n,s);let d=e.map(e=>{let t="user";return("assistant"===e.role||"model"===e.role||"system"===e.role)&&(t="model"),{role:t,parts:[{text:e.content||""}]}}),c=`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:streamGenerateContent?alt=sse&key=${r}`,u=new AbortController,p=setTimeout(()=>u.abort(),1e4);try{i=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:d,systemInstruction:{parts:[{text:l}]},generationConfig:{temperature:void 0!==n.temperature?Number(n.temperature):"admin"===t?.5:.2,maxOutputTokens:8192}}),signal:u.signal}),clearTimeout(p)}catch(e){return clearTimeout(p),console.error("Gemini Fallback connection failed or timed out:",e),N("⚠️ **NaariAI Assistant Error:** Google Gemini fallback failed (connection timed out or error).")}if(!i.ok){let e=await i.json().catch(()=>({}));console.error("Gemini Fallback API Error:",e);let t=e.error?.message||"Unknown error";return N(`⚠️ **NaariAI Assistant Error:** Google Gemini API returned an error: "${t}".`)}let h=new TextEncoder,m=new TextDecoder,g="customer"===t,f=new ReadableStream({async start(r){if(!i.body)return void r.close();let n=i.body.getReader(),s="",l="";try{for(;;){let{done:e,value:t}=await n.read();if(e)break;let a=(s+=m.decode(t,{stream:!0})).split("\n");for(let e of(s=a.pop()||"",a)){let t=e.trim();if(t&&t.startsWith("data: "))try{let e=t.slice(6),a=JSON.parse(e),n=a.candidates?.[0]?.content?.parts?.[0]?.text||"";n&&(r.enqueue(h.encode(n)),l+=n)}catch(e){}}}if(s&&s.startsWith("data: "))try{let e=s.slice(6).trim(),t=JSON.parse(e),a=t.candidates?.[0]?.content?.parts?.[0]?.text||"";a&&(r.enqueue(h.encode(a)),l+=a)}catch(e){}g&&await (0,y.logConversation)(o,e,l,t,a)}catch(e){console.error("Error reading Gemini stream:",e),r.error(e)}finally{r.close()}}});return new Response(f,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}function v(e,t=null){let{systemInstruction:a,customKnowledge:r,personaTone:n,includeTrips:o,includeDepartures:i,includeFaqs:s,includePolicies:l,qaPairs:d}=e||{},c="";if(!1!==o){let e=(0,E.getMergedTrips)();c=t?"\n\n--- ACTIVE TRIP PACKAGES ---\n"+(e=e.filter(e=>e.title.toLowerCase().includes(t)||e.slug.toLowerCase().includes(t))).map(e=>`- Trip: ${e.title}
  Slug: ${e.slug}
  Duration: ${e.durationDays} Days / ${e.durationNights} Nights
  Price Starts: ₹${e.priceFrom}
  Highlights: ${e.highlights?.join(", ")||""}
  Brief: ${e.shortDescription}
  Safety Policy: ${e.itineraryChangePolicy||""}`).join("\n\n"):"\n\n--- AVAILABLE TRIP PACKAGES (OVERVIEW) ---\n"+e.map(e=>`- Trip: ${e.title} (${e.durationDays}D/${e.durationNights}N) | Price starts at ₹${e.priceFrom} | Slug: ${e.slug}
  Brief: ${e.shortDescription}`).join("\n")}let u="";if(!1!==i){let e=(0,E.getMergedDepartures)();t&&(e=e.filter(e=>e.tripSlug.toLowerCase().includes(t))),u="\n\n--- SCHEDULED DEPARTURES ---\n"+e.map(e=>`- Trip: ${e.tripSlug} (Start: ${e.startDate}, End: ${e.endDate}, Status: ${e.status}, Price: ₹${e.price||"N/A"})`).join("\n")}let p="";if(!1!==s){let e=(0,E.getMergedFAQs)();p="\n\n--- FREQUENTLY ASKED QUESTIONS & SAFETY INFO ---\n"+(e=t?e.filter(e=>e.question.toLowerCase().includes(t)||e.answer.toLowerCase().includes(t)):e.slice(0,5)).map(e=>`Q: ${e.question}
A: ${e.answer}`).join("\n\n")}let h="";!1!==l&&(h="\n\n--- SITE SAFETY & OPERATIONAL POLICIES ---\n"+(0,E.getMergedPolicies)().map(e=>`Title: ${e.title} (v${e.version||"1.0"}, Updated: ${e.updated||"N/A"})
${e.body}`).join("\n\n"));let m=`You are "NaariAI", the official women's safety & group travel assistant for TripNaari.
TripNaari is India's leading travel brand focusing on safe solo and group travel experiences for women, sisters, mothers, and daughters.`;"professional"===n?m+=`

TONE OF VOICE:
- Maintain a highly professional, concise, direct, and factual tone.
- Focus on clear information delivery without extra conversational filler.`:"adventurous"===n?m+=`

TONE OF VOICE:
- Maintain an extremely energetic, adventurous, and enthusiastic tone.
- Inspire excitement for exploring the outdoors, high-altitude treks, and making lifelong road trip memories.`:m+=`

TONE OF VOICE:
- Be extremely warm, friendly, encouraging, and supportive.
- Emphasize safety, sisterhood, and verified room lock audits.`;let g=a||`${m}
 
YOUR INSTRUCTIONS:
1. ONLY answer questions using the provided TripNaari information listed below.
2. If a customer is asking to book a trip or wants a customized itinerary, encourage them to fill out our quick Enquiry/Booking Form. You can output "[SHOW_ENQUIRY_FORM]" at the end of your response to trigger the form interface inside the chat drawer.
3. If a user asks about topics completely unrelated to TripNaari (e.g. coding, cooking recipes, other travel operators, general news), politely state that you are only programmed to help with TripNaari trips and safety queries.
4. Do NOT hallucinate prices, dates, or destinations that are not in the context below.`,f="";if(d&&Array.isArray(d)&&d.length>0){let e=d;f="\n\n--- STRUCTURED TRAINING DATA (Q&A) ---\n"+(e=t?e.filter(e=>e.question.toLowerCase().includes(t)||e.answer.toLowerCase().includes(t)):e.slice(0,4)).map(e=>`Q: ${e.question}
A: ${e.answer}`).join("\n\n")}let A=r?`

--- ADDITIONAL CUSTOM KNOWLEDGE & RULES ---
${r}`:"",T=`

--- BUDGET & MATH ACCURACY RULES (CRITICAL) ---
1. BUDGET DEFINITION: If a user specifies a budget of X for N people, the total cost for ALL travelers combined must be less than or equal to X. (e.g. ₹20,000 budget for 2 people means the maximum total cost is ₹20,000).
2. STEP-BY-STEP FILTERING:
   - For each active trip in our catalog, calculate the total cost: (Price per Person * N).
   - Compare the total cost with the user's budget X.
   - If (Price per Person * N) <= X, then the package is a MATCHING package.
   - If (Price per Person * N) > X, then the package is NOT a matching package.
3. OUTPUT RULES:
   - If there are any MATCHING packages, list them clearly as fitting options. Show the math calculation explicitly (e.g. "Tirthan & Jibhi Whispering Pines: ₹9,999 per person * 2 travelers = ₹19,998 total, which fits your budget").
   - If a package fits, do NOT state that "We do not have packages under ₹X". Recommend the matching packages directly.
   - If and only if absolutely ZERO packages fit, state: "We do not have any packages under ₹X for N people. The cheapest option available is..."`,y=`

--- GROUNDING & DESTINATION LIMITS (CRITICAL) ---
1. STRICT DATA LIMIT: You are ONLY allowed to recommend destinations and trip packages that are explicitly listed in the "ACTIVE TRIP PACKAGES" section below.
2. NO HALLUCINATIONS: Do NOT recommend any external cities, hill stations, beaches, or countries (such as Shimla, Manali, Mussoorie, Goa, Delhi, Nepal, Bhutan, Thailand, etc.) that are not in the active database.
3. BUDGET BOUNDARY: If a user specifies a budget and we have no packages within that budget, state: "We do not have packages fitting your budget of ₹X." Do NOT suggest external travel packages as alternatives.`;return`${g}
${T}
${y}
${c}
${u}
${p}
${h}
${f}
${A}`}function C(e,t){let a=e?`Current CMS Page Path: ${e.pathname||"Dashboard"}
Active Context: ${JSON.stringify(e)}`:"Dashboard",r=t?.stats||{},n=t?.leads||[],o=t?.departures||[],i=t?.transactions||[];return`You are the TripNaari CMS AI Copilot. You assist the website administration team directly inside their secure control panel.
You have context-aware access to the active CMS database statistics, leads, scheduled departures, and financial transactions.

--- SYSTEM NAVIGATION COMMANDS (CRITICAL) ---
If the admin wants to open a page, view details, go somewhere, or search (e.g. "go to departures", "open finance", "show me leads", "navigate to blog creator", "show Kashmir departures"), append a navigation trigger tag at the very end of your message:
[NAVIGATE:/admin/relative-path]
Examples:
- Open departures page: [NAVIGATE:/admin/departures]
- Search departures for Kashmir: [NAVIGATE:/admin/departures?search=kashmir]
- Open finance tracker: [NAVIGATE:/admin/finance]
- Open CRM/leads board: [NAVIGATE:/admin/leads]
- Open blog manager: [NAVIGATE:/admin/blogs]
- Open AI settings: [NAVIGATE:/admin/ai-settings]

--- DATABASE WRITE COMMANDS (CRITICAL) ---
If the admin asks you to update a lead's status (e.g. "change Sharin's status to contacted" or "mark Priya as booked"), you MUST trigger the database write by appending an update tag in your response:
[UPDATE_LEAD_STATUS:id:new_status]
Get the correct numeric ID from the CRM leads list below.
Valid statuses must be exactly one of these lowercase strings: new, contacted, itinerary_shared, payment_pending, booked, lost, support_needed.
Do not format this tag with asterisks, bolding, or markdown. Output it exactly in brackets.
Example: [UPDATE_LEAD_STATUS:3:booked]

--- ON-SCREEN ACTION TRIGGERS (CRITICAL) ---
If the user asks you to send or draft a WhatsApp follow-up or Email to a lead, you must NOT pretend that you have sent it yourself (since you are a chat assistant and cannot execute browser redirections directly). Instead:
1. Draft the message body.
2. Inform the admin that they can send it by clicking the action button that will appear below your message card.
3. Append the correct target information tag:
   - For WhatsApp triggers: [WHATSAPP_TARGET:phone_number]
   - For Email triggers: [EMAIL_TARGET:email_address]
Example:
"I have drafted the follow-up message for Sharin. Click the WhatsApp button below to send it:
[WHATSAPP_TARGET:9861806115]"
Do not format these tags with asterisks or markdown. Output them exactly in brackets.

--- ACTIVE STATISTICS ---
- Total Leads: ${r.leads||0}
- Total Revenue: ₹${r.totalRevenue||0}
- Total Expenses: ₹${r.totalExpenses||0}
- Net Profit: ₹${r.netProfit||0}
- Testimonials: ${r.testimonials||0}
- Active Trips: ${r.trips||0}

--- ACTIVE CRM LEADS ---
${n.map(e=>`- ID: ${e.id}, Name: ${e.name}, Email: ${e.email}, Phone: ${e.phone||"N/A"}, Destination: ${e.destination||"N/A"}, Budget: ${e.budget||"N/A"}, Status: ${e.status}, Created: ${e.createdAt}`).join("\n")}

--- ACTIVE DEPARTURES SCHEDULE ---
${o.map(e=>`- Trip: ${e.tripSlug}, Dates: ${e.startDate} to ${e.endDate}, Seats Booked: ${e.seatsBooked}/${e.seatsTotal}, Price: ₹${e.price}, Status: ${e.status}`).join("\n")}

--- RECENT FINANCIAL TRANSACTIONS ---
${i.map(e=>`- Date: ${e.date}, Type: ${e.type}, Amount: ₹${e.amount}, Category: ${e.category}, Description: ${e.description||""}`).join("\n")}

YOUR INSTRUCTIONS:
1. Help the admin team create content, draft replies, summarize logs, and analyze statistics.
2. Keep your answers concise, professional, and formatted in clean markdown.
3. If the user asks to write/draft a blog post or trip itinerary, format the fields in a structured JSON code block at the end (with keys like 'title', 'slug', 'category', 'excerpt', and 'content' for blogs) so the admin can click "Apply to Form" to populate inputs automatically.
4. Emphasize warm, professional, clear, and safety-oriented communication when drafting templates.
5. DRAFTING REPLIES/MESSAGES: When asked to draft a follow-up, reply, WhatsApp text, or email for a lead, output ONLY the drafted message content itself along with the required brackets target tag (e.g. [WHATSAPP_TARGET:phone] or [EMAIL_TARGET:email]). Do NOT output conversational introductions, descriptions, explanations, meta-text, or instructions on what button the admin should click. Keep the response limited strictly to the text that needs to be sent to the lead.
6. HANDLING SEND CONFIRMATIONS: If the admin tells you to "send message", "send it", "confirm", or similar, do NOT claim that you have sent it. Remind the admin to click the interactive action button (e.g. "WhatsApp Lead" or "Mail Lead") located directly under the drafted message bubble in the chat log, explaining that you do not have direct automated messaging capabilities.

--- CURRENT PAGE & CONTEXT ---
${a}`}e.i(79594).default.setDefaultResultOrder("ipv4first"),e.s(["POST",0,w],76021);var S=e.i(76021);let b=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/chat/route.ts",nextConfigOutput:"standalone",userland:S,...{}}),{workAsyncStorage:O,workUnitAsyncStorage:k,serverHooks:P}=b;async function $(e,t,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),b.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let T="/api/chat/route";T=T.replace(/\/index$/,"")||"/";let E=await b.prepare(e,t,{srcPage:T,multiZoneDraftMode:!1});if(!E)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:y,deploymentId:I,params:N,nextConfig:x,parsedUrl:w,isDraftMode:R,prerenderManifest:v,routerServerContext:C,isOnDemandRevalidate:S,revalidateOnlyGenerated:O,resolvedPathname:k,clientReferenceManifest:P,serverActionsManifest:$}=E,D=(0,s.normalizeAppPath)(T),_=!!(v.dynamicRoutes[D]||v.routes[k]),G=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,w,!1):t.end("This page could not be found"),null);if(_&&!R){let e=!!v.routes[k],t=v.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(x.adapterPath)return await G();throw new f.NoFallbackError}}let M=null;!_||b.isDev||R||(M="/index"===(M=k)?"/":M);let U=!0===b.isDev||!_,L=_&&!U;$&&P&&(0,i.setManifestsSingleton)({page:T,clientReferenceManifest:P,serverActionsManifest:$});let q=e.method||"GET",F=(0,o.getTracer)(),H=F.getActiveScopeSpan(),j=!!(null==C?void 0:C.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),V=(0,n.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,x,v,K);null==V||V.resetRequestCache(),globalThis.__incrementalCache=V;let W={params:N,previewProps:v.preview,renderOpts:{experimental:{authInterrupts:!!x.experimental.authInterrupts},cacheComponents:!!x.cacheComponents,supportsDynamicResponse:U,incrementalCache:V,cacheLifeProfiles:x.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,n)=>b.onRequestError(e,t,r,n,C)},sharedContext:{buildId:y,deploymentId:I}},Y=new l.NodeNextRequest(e),B=new l.NodeNextResponse(t),X=d.NextRequestAdapter.fromNodeNextRequest(Y,(0,d.signalFromNodeResponse)(t));try{let n,i=async e=>b.handle(X,W).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=F.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${q} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",r),n.updateName(t))}else e.updateName(`${q} ${T}`)}),s=async n=>{var o,s;let l=async({previousCacheEntry:a})=>{try{if(!K&&S&&O&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await i(n);e.fetchMetrics=W.renderOpts.fetchMetrics;let s=W.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let l=W.renderOpts.collectedTags;if(!_)return await (0,p.sendResponse)(Y,B,o,W.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(o.headers);l&&(t[g.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==W.renderOpts.collectedRevalidate&&!(W.renderOpts.collectedRevalidate>=g.INFINITE_CACHE)&&W.renderOpts.collectedRevalidate,r=void 0===W.renderOpts.collectedExpire||W.renderOpts.collectedExpire>=g.INFINITE_CACHE?void 0:W.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:T,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:L,isOnDemandRevalidate:S})},!1,C),t}},d=await b.handleResponse({req:e,nextConfig:x,cacheKey:M,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:v,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:O,responseGenerator:l,waitUntil:r.waitUntil,isMinimalMode:K});if(!_)return null;if((null==d||null==(o=d.value)?void 0:o.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(s=d.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",S?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),R&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,h.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&_||c.delete(g.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,m.getCacheControlHeader)(d.cacheControl)),await (0,p.sendResponse)(Y,B,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};j&&H?await s(H):(n=F.getActiveScopeSpan(),await F.withPropagatedContext(e.headers,()=>F.trace(c.BaseServerSpan.handleRequest,{spanName:`${q} ${T}`,kind:o.SpanKind.SERVER,attributes:{"http.method":q,"http.target":e.url}},s),void 0,!j))}catch(t){if(t instanceof f.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:L,isOnDemandRevalidate:S})},!1,C),_)throw t;return await (0,p.sendResponse)(Y,B,new Response(null,{status:500})),null}}e.s(["handler",0,$,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:O,workUnitAsyncStorage:k})},"routeModule",0,b,"serverHooks",0,P,"workAsyncStorage",0,O,"workUnitAsyncStorage",0,k],61378)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1fccc7f._.js.map