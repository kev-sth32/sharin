var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/notifications/generate/route.js")
R.c("server/chunks/[root-of-the-server]__1nyw-fg._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/lib_0snc8bo._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_notifications_generate_route_actions_0hjxvp2.js")
R.m(56332)
module.exports=R.m(56332).exports
