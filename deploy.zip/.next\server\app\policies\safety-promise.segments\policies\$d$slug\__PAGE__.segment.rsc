1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0d--xggs96671.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2l3o-5ecmo0dl.js"],"OutletBoundary"]
4:"$Sreact.suspense"
2:T458,## Trip leader accountability
Every departure has one verified woman trip leader. She stays in same property, travels in same vehicle, carries first-aid, oxygen (for Himalaya), emergency fund.

## Verified ecosystem
- Driver: police verified, 5+ years hill experience, no night driving without consent
- Hotel: safety audit (door lock, location, solo women reviews), women-only floor where possible
- Homestay: run by women / family, local reference

## Emergency card
Printed + WhatsApp: trip leader phone, operations 24x7, local police, hospital, TripNaari founder escalation.

## Communication
WhatsApp group created 48h before. Live location shared on travel days. Trip leader active 6am-10pm, emergency line 24x7.

## Feedback escalation
Level1: Trip leader immediate, Level2: Operations 24x7 +91 9XXXX 9XXXX (2min pick), Level3: founder@tripnaari.com (24h response). Monthly safety report in Instagram highlights.

## What we don't tolerate
Harassment, non-consensual behavior, hidden costs, bait-and-switch hotels — zero tolerance. Immediate corrective action, refund where appropriate, public learning.0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"max-w-[800px] mx-auto px-4 md:px-8 py-12","children":[["$","h1",null,{"className":"font-display font-bold text-[32px] leading-tight text-[#13253D]","children":"Safety Promise & Accountability"}],["$","div",null,{"className":"mt-2 text-[12px] uppercase tracking-widest font-bold text-[#FF4A7D]","children":["Last updated: ","10 Jan 2026"," • Version ","1.4"]}],["$","div",null,{"className":"mt-8 rounded-2xl bg-white border border-[#F1D9D0] p-6 md:p-8 card-shadow text-left","children":["$","pre",null,{"className":"whitespace-pre-wrap font-sans text-[14px] leading-relaxed text-[#3D4A5E]","children":"$2"}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"_Ct4_PonEya3o_cmY5CJ1"}
5:null
