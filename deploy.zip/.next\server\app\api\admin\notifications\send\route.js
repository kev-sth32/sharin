var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/notifications/send/route.js")
R.c("server/chunks/[externals]__1yusw75._.js")
R.c("server/chunks/[root-of-the-server]__0343mfw._.js")
R.c("server/chunks/[root-of-the-server]__156sndz._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_notifications_send_route_actions_0r2lkpw.js")
R.m(61144)
module.exports=R.m(61144).exports
