var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0gp1mjy._.js")
R.c("server/chunks/[root-of-the-server]__056mgo_._.js")
R.m(62395)
module.exports=R.m(62395).exports
