module.exports=[37401,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chat_settings_route_actions_17p07kn.js.map