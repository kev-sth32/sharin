var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/gallery/route.js")
R.c("server/chunks/[root-of-the-server]__1rjxb9t._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_1t73ase._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_gallery_route_actions_0qe7l7l.js")
R.m(18281)
module.exports=R.m(18281).exports
