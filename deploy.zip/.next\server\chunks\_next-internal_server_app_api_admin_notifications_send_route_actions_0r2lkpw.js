module.exports=[4716,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_notifications_send_route_actions_0r2lkpw.js.map