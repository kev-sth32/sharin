var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/settings/route.js")
R.c("server/chunks/[root-of-the-server]__1hqkb-6._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/lib_0snc8bo._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_settings_route_actions_17p07kn.js")
R.m(36785)
module.exports=R.m(36785).exports
