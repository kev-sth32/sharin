var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/upload/route.js")
R.c("server/chunks/[root-of-the-server]__1g9px01._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_upload_route_actions_0gtguvx.js")
R.m(65334)
module.exports=R.m(65334).exports
