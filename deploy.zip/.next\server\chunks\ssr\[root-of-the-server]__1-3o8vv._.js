module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},64240,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},77969,a=>{"use strict";var b=a.i(22734),c=a.i(14747),d=a.i(82193);function e(a,d=[]){let f=c.default.join(process.cwd(),".data"),g=c.default.join(f,a);if(!b.default.existsSync(g))return d;try{return JSON.parse(b.default.readFileSync(g,"utf-8"))}catch{return d}}a.s(["getHomepageGallery",0,function(){let a=e("homepage_gallery.json",[]);return a&&0!==a.length?a:[{src:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80",alt:"Ocean beach waves"},{src:"https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&q=80",alt:"Travel camera map"},{src:"https://images.unsplash.com/photo-1506929562872-bb421503ef21?w=600&q=80",alt:"Palm tree beach"},{src:"https://images.unsplash.com/photo-1527631746610-bca00a040d60?w=600&q=80",alt:"Alleyway walking"},{src:"https://images.unsplash.com/photo-1533105079780-92b9be482077?w=600&q=80",alt:"Waterfalls and mountains"},{src:"https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&q=80",alt:"Lake and boats"}]},"getMergedDepartures",0,function(){let a=e("departures.json",[]);if(0===a.length&&d.tripPackagesSeed.length>0){let a=new Date,b=[],c=1;return d.tripPackagesSeed.forEach(d=>{let e=new Date(a.getTime()+6048e5),f=new Date(e.getTime()+24*d.durationDays*36e5),g=new Date(a.getTime()+1728e6),h=new Date(g.getTime()+24*d.durationDays*36e5);b.push({id:c++,tripSlug:d.slug,startDate:e.toISOString().slice(0,10),endDate:f.toISOString().slice(0,10),seatsTotal:14,seatsBooked:8,price:d.priceFrom,status:"open",isGuaranteed:!1}),b.push({id:c++,tripSlug:d.slug,startDate:g.toISOString().slice(0,10),endDate:h.toISOString().slice(0,10),seatsTotal:16,seatsBooked:14,price:d.priceFrom,status:"filling_fast",isGuaranteed:!0})}),b}return a},"getMergedFAQs",0,function(){let a=e("faqs.json",[]);return 0===a.length?d.faqsSeed.map((a,b)=>({id:b+1,...a})):a},"getMergedLeaders",0,function(){let a=e("leaders_overrides.json",[]),b=e("leaders_custom.json",[]);return[...d.tripLeadersSeed.map(b=>{let c=a.find(a=>a.slug===b.slug);return c?{...b,...c}:b}),...b]},"getMergedPolicies",0,function(){let a=e("policies.json",[]);if(0===a.length){let a=[{slug:"cancellation-refund",title:"Booking & Cancellation Policy",version:"2.2",updated:"10 Aug 2026",body:`Please carefully review our timeline-based cancellation schedule and refund distribution metrics detailed below before finalizing your slot registration.

--------------------------------------------------------------------------------
CANCELLATION TIMELINE WINDOW & REFUND TERMS
--------------------------------------------------------------------------------

1. 30 Days or more before departure date
   * Refund: 100% Refund
   * Terms: Full amount refunded back to source account. No hidden penalties.

2. Between 15 to 30 Days before departure date
   * Refund: 50% Refund
   * Terms: Half package cost refunded or 80% dynamic rollover credit voucher provided.

3. Between 7 to 14 Days before departure date
   * Refund: 25% Refund
   * Terms: Quarterly package cost returned. Operational logistics fees apply.

4. Less than 7 Days before departure date
   * Refund: No Refund (0%)
   * Terms: Strictly non-refundable due to advance mountain vehicle and hotel bookings.

--------------------------------------------------------------------------------
SPECIAL POLICY NOTES
--------------------------------------------------------------------------------
Permit application processing tokens, special high altitude entry clearances, and customized border transit passes are fully non-refundable once initiated by state regulators. In instances of unexpected road blockages, landslides, natural emergencies, or severe snowfall restrictions, preventing entry past critical checkpoints, alternate valley exploration circuits will be systematically organized by TripNaari coordinators; direct payment cash disbursements cannot be processed under state-leased environmental restrictions.`},{slug:"safety-promise",title:"Safety Promise & Accountability",version:"1.4",updated:"10 Jan 2026",body:`## Trip leader accountability
Every departure has one verified woman trip leader. She stays in same property, travels in same vehicle, carries first-aid, oxygen (for Himalaya), emergency fund.

## Verified ecosystem
- Driver: police verified, 5+ years hill experience, no night driving without consent
- Hotel: safety audit (door lock, location, solo women reviews), women-only floor where possible
- Homestay: run by women / family, local reference

## Emergency card
Printed + WhatsApp: trip leader phone, operations 24x7, local police, hospital, TripNaari founder escalation.

## Communication
WhatsApp group created 48h before. Live location shared on travel days. Trip leader active 6am-10pm, emergency line 24x7.

## Feedback escalation
Level1: Trip leader immediate, Level2: Operations 24x7 +91 92827 94457 (2min pick), Level3: founder@tripnaari.com (24h response). Monthly safety report in Instagram highlights.

## What we don't tolerate
Harassment, non-consensual behavior, hidden costs, bait-and-switch hotels — zero tolerance. Immediate corrective action, refund where appropriate, public learning.`},{slug:"privacy-policy",title:"Privacy Policy - Your Data, Your Sisterhood",version:"1.0",updated:"01 Jan 2026",body:`We collect name, email, phone, travel preferences to craft trip. We store in MySQL encrypted at rest. We use your phone only for trip-related WhatsApp (no marketing without opt-in). We never sell data to third party.

You can request deletion via privacy@tripnaari.com. Newsletter unsubscribe anytime.

Cookies: we use analytics (anonymized) and conversion tracking. No creepy cross-site tracking.

DMCA: TripNaari community photos used with consent. If you want yours removed, email.

Contact DPO: dpo@tripnaari.com, Bangalore.`},{slug:"terms-conditions",title:"Terms & Conditions",version:"1.2",updated:"05 Jan 2026",body:`Booking confirms you are 18+ or guardian consent for daughter 12+. You agree to safety code: respect local culture, no drugs, no harassment.

TripNaari is not liable for weather, political curfew, natural disasters beyond control — but we will provide alternatives or refund per cancellation policy.

Itinerary may change due to safety, we communicate 12h prior.

Payment: 30% advance to confirm seat, 100% 15 days before. EMI via partner.

Jurisdiction: Bangalore courts.

Recognised by MSME & Startup India. We love you, Naari.`}],d=c.default.join(process.cwd(),".data");return b.default.existsSync(d)||b.default.mkdirSync(d,{recursive:!0}),b.default.writeFileSync(c.default.join(d,"policies.json"),JSON.stringify(a,null,2)),a}return a},"getMergedTestimonials",0,function(){let a=e("testimonials_overrides.json",[]);return[...d.testimonialsSeed.map((a,b)=>({id:1e3+b,isApproved:!0,isFeatured:!0,...a})),...a].filter(a=>!1!==a.isApproved)},"getMergedTrips",0,function(){let a=e("trips_overrides.json",[]),b=e("trips_custom.json",[]);return[...d.tripPackagesSeed.map(b=>{let c=a.find(a=>a.slug===b.slug);return c?.isDeleted?null:c?{...b,...c}:b}).filter(Boolean),...b].filter(a=>!1!==a.isPublished)},"getSettings",0,function(){let a=e("settings.json",[]),b=[{icon:"Shield",title:"Women trip leader 24x7, not just a driver",desc:"Verified, wilderness first responder trained, stays in same hotel, accountable via escalation card."},{icon:"Map",title:"Hotel category revealed at booking, name 7 days before",desc:"We show you 2 sample properties and exact timeline. No bait-and-switch. If changed, upgrade at our cost."},{icon:"Wallet",title:"Transparent inclusion & refund timelines",desc:"Every trip page lists inclusions, exclusions, cancellation slabs with refund processing days (7-10 days)."},{icon:"Users",title:"Community, not just customers",desc:"Solo travelers, housewives, mothers, grandmothers travel together. Pre-trip icebreaker call."},{icon:"Clock",title:"Itinerary change policy in writing",desc:"Weather, traffic, safety, low group size: alternatives or refund options shared 12 hours prior. Never abandoned."},{icon:"Heart",title:"Food, safety needs actually heard",desc:"Jain, vegan, kid-friendly, medical needs collected in form and acted on. Not just a marketing checkbox."}],c="🎉 Limited Offer: Get ₹2,000 Off on your first booking! Code: SISTERHOOD2000 • Group Discount: Book for 4 or more girls and get extra ₹1,500 off per person! • Book early and secure your slot with just ₹5,000 token amount!",d="Women-Only Travel Experience",f='Solo on Paper.<br />\n<span class="font-serif italic font-normal text-[#FF4A7D]">Together in Spirit.</span>',g="Discover safety-first small group trips for women. Experience local cultures, form lifetime friendships, and explore the world with our experienced Trip Leaders.",h="⚡ {count} Naaris enquired last hour",i=["https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=1600&q=80","https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1600&q=80","https://images.unsplash.com/photo-1527631746610-bca00a040d60?w=1600&q=80"];return!a||Array.isArray(a)||"object"!=typeof a?{marqueeText:c,whyChooseBadge:"Why 6000+ women choose TripNaari",whyChooseTitle:"Safety is not a tagline.\nIt is accountability.",whyChooseDesc:"Public reviews love our safety, some mention operational hiccups. So we fixed it: every touchpoint now has a written policy, escalation, and timeline.",whyChooseReasons:b,heroBadge:d,heroTitle:f,heroSubtitle:g,urgencyText:h,heroImages:i,heroTitleSize:"Large",heroSubtitleSize:"Medium",pill1Badge:"Most Loved",pill1Title:"Kashmir Tulip • 5D",pill1Desc:"₹21,999 • 8 seats",pill2Badge:"Weekend",pill2Title:"Tirthan 3D • Solo",pill2Desc:"₹9,999 • Fri"}:{marqueeText:a.marqueeText||c,whyChooseBadge:a.whyChooseBadge||"Why 6000+ women choose TripNaari",whyChooseTitle:a.whyChooseTitle||"Safety is not a tagline.\nIt is accountability.",whyChooseDesc:a.whyChooseDesc||"Public reviews love our safety, some mention operational hiccups. So we fixed it: every touchpoint now has a written policy, escalation, and timeline.",whyChooseReasons:a.whyChooseReasons||b,heroBadge:a.heroBadge||d,heroTitle:a.heroTitle||f,heroSubtitle:a.heroSubtitle||g,urgencyText:a.urgencyText||h,heroImages:a.heroImages||i,heroTitleSize:a.heroTitleSize||"Large",heroSubtitleSize:a.heroSubtitleSize||"Medium",pill1Badge:a.pill1Badge||"Most Loved",pill1Title:a.pill1Title||"Kashmir Tulip • 5D",pill1Desc:a.pill1Desc||"₹21,999 • 8 seats",pill2Badge:a.pill2Badge||"Weekend",pill2Title:a.pill2Title||"Tirthan 3D • Solo",pill2Desc:a.pill2Desc||"₹9,999 • Fri"}}])},26758,a=>{a.v("/_next/static/media/favicon.2vob68tjqpejf.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},38872,a=>{"use strict";let b={src:a.i(26758).default,width:256,height:256};a.s(["default",0,b])},28788,a=>{"use strict";var b=a.i(7997);a.i(70396);var c=a.i(73727),d=a.i(77969);async function e(){return(0,d.getMergedPolicies)().map(a=>({slug:a.slug}))}async function f({params:a}){let{slug:e}=await a,g=(0,d.getMergedPolicies)().find(a=>a.slug===e);return g?(0,b.jsxs)("div",{className:"max-w-[800px] mx-auto px-4 md:px-8 py-12",children:[(0,b.jsx)("h1",{className:"font-display font-bold text-[32px] leading-tight text-[#13253D]",children:g.title}),(0,b.jsxs)("div",{className:"mt-2 text-[12px] uppercase tracking-widest font-bold text-[#FF4A7D]",children:["Last updated: ",g.updated," • Version ",g.version]}),(0,b.jsx)("div",{className:"mt-8 rounded-2xl bg-white border border-[#F1D9D0] p-6 md:p-8 card-shadow text-left",children:(0,b.jsx)("pre",{className:"whitespace-pre-wrap font-sans text-[14px] leading-relaxed text-[#3D4A5E]",children:g.body})})]}):(0,c.notFound)()}a.s(["default",0,f,"generateStaticParams",0,e])},97672,a=>{a.n(a.i(28788))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1-3o8vv._.js.map