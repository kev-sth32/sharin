var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/notifications/stats/route.js")
R.c("server/chunks/[root-of-the-server]__1cfi8c7._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/[root-of-the-server]__156sndz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_notifications_stats_route_actions_144_oru.js")
R.m(77545)
module.exports=R.m(77545).exports
