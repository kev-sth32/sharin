var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/notifications/send/route.js")
R.c("server/chunks/[externals]__0ngthtk._.js")
R.c("server/chunks/[root-of-the-server]__1yedmtf._.js")
R.c("server/chunks/[root-of-the-server]__16xri54._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_notifications_send_route_actions_0r2lkpw.js")
R.m(61144)
module.exports=R.m(61144).exports
