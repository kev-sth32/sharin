var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/route.js")
R.c("server/chunks/[root-of-the-server]__0gp10mp._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_leads_route_actions_10t572w.js")
R.m(747)
module.exports=R.m(747).exports
