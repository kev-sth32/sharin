var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[externals]__1uwttca._.js")
R.c("server/chunks/lib_0snc8bo._.js")
R.c("server/chunks/_1t73ase._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1fccc7f._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_route_actions_1d_pld-.js")
R.m(61378)
module.exports=R.m(61378).exports
