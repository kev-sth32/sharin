globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/_Ct4_PonEya3o_cmY5CJ1/_buildManifest.js",
    "static/_Ct4_PonEya3o_cmY5CJ1/_ssgManifest.js",
    "static/_Ct4_PonEya3o_cmY5CJ1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/0ha4m18glnjqn.js",
    "static/chunks/1--cgnh_vjpor.js",
    "static/chunks/25o46h8mdjlrg.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/0yjcepc8j0p3k.js",
    "static/chunks/turbopack-28u4l47q8e25q.js"
  ]
};
