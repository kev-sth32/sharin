1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0d--xggs96671.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2l3o-5ecmo0dl.js"],"OutletBoundary"]
4:"$Sreact.suspense"
2:T696,Please carefully review our timeline-based cancellation schedule and refund distribution metrics detailed below before finalizing your slot registration.

--------------------------------------------------------------------------------
CANCELLATION TIMELINE WINDOW & REFUND TERMS
--------------------------------------------------------------------------------

1. 30 Days or more before departure date
   * Refund: 100% Refund
   * Terms: Full amount refunded back to source account. No hidden penalties.

2. Between 15 to 30 Days before departure date
   * Refund: 50% Refund
   * Terms: Half package cost refunded or 80% dynamic rollover credit voucher provided.

3. Between 7 to 14 Days before departure date
   * Refund: 25% Refund
   * Terms: Quarterly package cost returned. Operational logistics fees apply.

4. Less than 7 Days before departure date
   * Refund: No Refund (0%)
   * Terms: Strictly non-refundable due to advance mountain vehicle and hotel bookings.

--------------------------------------------------------------------------------
SPECIAL POLICY NOTES
--------------------------------------------------------------------------------
Permit application processing tokens, special high altitude entry clearances, and customized border transit passes are fully non-refundable once initiated by state regulators. In instances of unexpected road blockages, landslides, natural emergencies, or severe snowfall restrictions, preventing entry past critical checkpoints, alternate valley exploration circuits will be systematically organized by TripNaari coordinators; direct payment cash disbursements cannot be processed under state-leased environmental restrictions.0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"max-w-[800px] mx-auto px-4 md:px-8 py-12","children":[["$","h1",null,{"className":"font-display font-bold text-[32px] leading-tight text-[#13253D]","children":"Booking & Cancellation Policy"}],["$","div",null,{"className":"mt-2 text-[12px] uppercase tracking-widest font-bold text-[#FF4A7D]","children":["Last updated: ","10 Aug 2026"," • Version ","2.2"]}],["$","div",null,{"className":"mt-8 rounded-2xl bg-white border border-[#F1D9D0] p-6 md:p-8 card-shadow text-left","children":["$","pre",null,{"className":"whitespace-pre-wrap font-sans text-[14px] leading-relaxed text-[#3D4A5E]","children":"$2"}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"_Ct4_PonEya3o_cmY5CJ1"}
5:null
